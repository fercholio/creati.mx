(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,66359,e=>{"use strict";var t=(0,e.i(97955).__name)(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,"getIconStyles");e.s(["getIconStyles",()=>t])},342,e=>{"use strict";var t=e.i(52444),l=e.i(18620);e.s(["channel",0,(e,o)=>t.default.lang.round(l.default.parse(e)[o])],342)}]);