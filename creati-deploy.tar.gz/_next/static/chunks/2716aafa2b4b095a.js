(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,66359,t=>{"use strict";var e=(0,t.i(97955).__name)(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,"getIconStyles");t.s(["getIconStyles",()=>e])},86962,t=>{"use strict";var e=t.i(85012),a=t.i(88215),r=t.i(97955),i=(0,r.__name)((t,r,i,n)=>{t.attr("class",i);let{width:o,height:d,x:c,y:x}=s(t,r);(0,e.configureSvgSize)(t,d,o,n);let g=l(c,x,o,d,r);t.attr("viewBox",g),a.log.debug(`viewBox configured: ${g} with padding: ${r}`)},"setupViewPortForSVG"),s=(0,r.__name)((t,e)=>{let a=t.node()?.getBBox()||{width:0,height:0,x:0,y:0};return{width:a.width+2*e,height:a.height+2*e,x:a.x,y:a.y}},"calculateDimensionsWithPadding"),l=(0,r.__name)((t,e,a,r,i)=>`${t-i} ${e-i} ${a} ${r}`,"createViewBox");t.s(["setupViewPortForSVG",()=>i])},41225,t=>{"use strict";var e=t.i(97955);t.i(33518);var a=t.i(97875),r=(0,e.__name)((t,e)=>{let r;return"sandbox"===e&&(r=(0,a.select)("#i"+t)),("sandbox"===e?(0,a.select)(r.nodes()[0].contentDocument.body):(0,a.select)("body")).select(`[id="${t}"]`)},"getDiagramElement");t.s(["getDiagramElement",()=>r])},88819,t=>{"use strict";var e=t.i(85012),a=t.i(97955),r=t.i(99453);t.i(33518);var i=t.i(97875),s=(0,a.__name)((t,e)=>{let a=t.append("rect");if(a.attr("x",e.x),a.attr("y",e.y),a.attr("fill",e.fill),a.attr("stroke",e.stroke),a.attr("width",e.width),a.attr("height",e.height),e.name&&a.attr("name",e.name),e.rx&&a.attr("rx",e.rx),e.ry&&a.attr("ry",e.ry),void 0!==e.attrs)for(let t in e.attrs)a.attr(t,e.attrs[t]);return e.class&&a.attr("class",e.class),a},"drawRect"),l=(0,a.__name)((t,e)=>{s(t,{x:e.startx,y:e.starty,width:e.stopx-e.startx,height:e.stopy-e.starty,fill:e.fill,stroke:e.stroke,class:"rect"}).lower()},"drawBackgroundRect"),n=(0,a.__name)((t,a)=>{let r=a.text.replace(e.lineBreakRegex," "),i=t.append("text");i.attr("x",a.x),i.attr("y",a.y),i.attr("class","legend"),i.style("text-anchor",a.anchor),a.class&&i.attr("class",a.class);let s=i.append("tspan");return s.attr("x",a.x+2*a.textMargin),s.text(r),i},"drawText"),o=(0,a.__name)((t,e,a,i)=>{let s=t.append("image");s.attr("x",e),s.attr("y",a);let l=(0,r.sanitizeUrl)(i);s.attr("xlink:href",l)},"drawImage"),d=(0,a.__name)((t,e,a,i)=>{let s=t.append("use");s.attr("x",e),s.attr("y",a);let l=(0,r.sanitizeUrl)(i);s.attr("xlink:href",`#${l}`)},"drawEmbeddedImage"),c=(0,a.__name)(()=>({x:0,y:0,width:100,height:100,fill:"#EDF2AE",stroke:"#666",anchor:"start",rx:0,ry:0}),"getNoteRect"),x=(0,a.__name)(()=>({x:0,y:0,width:100,height:100,"text-anchor":"start",style:"#666",textMargin:0,rx:0,ry:0,tspan:!0}),"getTextObj"),g=(0,a.__name)(()=>{let t=(0,i.select)(".mermaidTooltip");return t.empty()&&(t=(0,i.select)("body").append("div").attr("class","mermaidTooltip").style("opacity",0).style("position","absolute").style("text-align","center").style("max-width","200px").style("padding","2px").style("font-size","12px").style("background","#ffffde").style("border","1px solid #333").style("border-radius","2px").style("pointer-events","none").style("z-index","100")),t},"createTooltip");t.s(["createTooltip",()=>g,"drawBackgroundRect",()=>l,"drawEmbeddedImage",()=>d,"drawImage",()=>o,"drawRect",()=>s,"drawText",()=>n,"getNoteRect",()=>c,"getTextObj",()=>x])},342,t=>{"use strict";var e=t.i(52444),a=t.i(18620);t.s(["channel",0,(t,r)=>e.default.lang.round(a.default.parse(t)[r])],342)},45561,t=>{"use strict";var e=t.i(36424);t.i(66359),t.i(41225),t.i(86962),t.i(23042),t.i(11859),t.i(88819),t.i(3437),t.i(29987),t.i(19466),t.i(15799),t.i(94647),t.i(8591),t.i(76768),t.i(80168),t.i(85012),t.i(88215);var a=(0,t.i(97955).__name)(t=>`${(0,e.styles_default)(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),r=(0,e.createFlowDiagram)({defaultLayout:"swimlane",styles:a});t.s(["diagram",()=>r])}]);